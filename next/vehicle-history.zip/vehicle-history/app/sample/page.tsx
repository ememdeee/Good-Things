import { SampleContent } from '@/components/sample-content'

export default function SamplePage() {
  return <SampleContent />
}

