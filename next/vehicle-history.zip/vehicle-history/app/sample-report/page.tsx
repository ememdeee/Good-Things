import { SampleReportContent } from '@/components/sample-report-content'

export default function SampleReport() {
  return <SampleReportContent />
}

