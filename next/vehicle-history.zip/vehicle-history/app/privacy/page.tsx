import { PrivacyPolicyContent } from '@/components/privacy-policy-content'

export default function PrivacyPolicy() {
  return <PrivacyPolicyContent />
}

