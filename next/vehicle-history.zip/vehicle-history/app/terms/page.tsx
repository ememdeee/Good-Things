import { TermsContent } from '@/components/terms-content'

export default function TermsPage() {
  return <TermsContent />
}

