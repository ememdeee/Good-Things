import { ForDealersContent } from '@/components/for-dealers-content'

export default function ForDealersPage() {
  return <ForDealersContent />
}

