import { LicensePlateLookupContent } from '@/components/license-plate-lookup-content'

export default function LicensePlateLookup() {
  return <LicensePlateLookupContent />
}

