import { VehicleHistoryContent } from '@/components/vehicle-history-content'

export default function VehicleHistory() {
  return <VehicleHistoryContent />
}

