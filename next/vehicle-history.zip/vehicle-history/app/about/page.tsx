import { AboutContent } from '@/components/about-content'

export default function AboutPage() {
  return <AboutContent />
}

