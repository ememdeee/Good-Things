import { ContactContent } from '@/components/contact-content'

export default function Contact() {
  return <ContactContent />
}

