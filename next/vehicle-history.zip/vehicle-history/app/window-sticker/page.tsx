import { WindowStickerContent } from '@/components/window-sticker-content'

export default function WindowSticker() {
  return <WindowStickerContent />
}

